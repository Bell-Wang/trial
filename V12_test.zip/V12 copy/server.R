library(shiny)
library(ggplot2)

shinyServer(function(input, output) {
  
  datasetInput <- reactive({
    v12_mil <- v12_mil[sample(nrow(v12_mil),input$n_sample, replace = F),]
    
    if (input$Occupation.Name != 'All'){
      v12_mil <- v12_mil[v12_mil$Occupation.Name==input$Occupation.Name,]}
    if (input$Education != 'All'){
      v12_mil <- v12_mil[v12_mil$Education==input$Education,]}
    if (input$income != 'All'){
      income_input_switch <- switch(input$income,'Under $10K'='A', 
                                    '10-19,999' = 'B', '20-29,999'='C', '30-39,999'='D', '40-49,999'='E', 
                                    '50-59,999'='F', '60-69,999'='G', '70-79,999'='H', '80-89,999'='I', 
                                    '90-99,999'='J', '100-149,999'='K', '150-174,999'='L','175-199,999'='M',
                                    '200-249,999'='N','250K+'='O')
      
      v12_mil <- v12_mil[v12_mil$income == income_input_switch,]
    }
    if (input$state != 'All'){
      v12_mil <- v12_mil[v12_mil$state == input$state,]
    }
    if (input$political != 'All'){
      political_input_switch <- switch(input$political,
                                       'Democratic'="D",
                                       'Republican'="R",
                                       'Independent'="I")
      v12_mil <- v12_mil[v12_mil$political == political_input_switch,]}
    v12_mil
  })
  
  clusterInput <- reactive({
    cluster_input_switch1 <- switch(input$var1,
                                    'age' = 'age',
                                    #'income' = 'income',
                                    'generation in household' =  'gen_in_household',
                                    'number of children' = 'num_of_children',
                                    'current home value' = 'curr_home_value',
                                    'education code' = 'education_code',
                                    'occupation' = 'Occupation')
    cluster_input_switch2 <- switch(input$var2,
                                    'age' = 'age',
                                    #'income' = 'income',
                                    'generation in household' =  'gen_in_household',
                                    'number of children' = 'num_of_children',
                                    'current home value' = 'curr_home_value',
                                    'education code' = 'education_code',
                                    'occupation' = 'Occupation')
    
    v12_mil[complete.cases(v12_mil[,c(cluster_input_switch1, cluster_input_switch2)]), 
            c(cluster_input_switch1, cluster_input_switch2)]
  })
  
  clusterAlgo <- reactive({
    kmeans(clusterInput(), input$clusters)
  })
  
  datasetInput_stat <- reactive({
    
    gp_df <- as.data.frame(table(v12_mil[,c('gender','political')]))
    gp_df <- gp_df[(gp_df$political!='' & gp_df$gender!=''),]
    names(gp_df)<-c('gender','political','number')
    gp_df})
  
  
  output$map <- renderLeaflet({
    leaflet() %>%
      addTiles() %>%
      setView(lng = -93.85, lat = 37.45, zoom = 4) %>%
      addCircleMarkers(lng = datasetInput()$my_lon, lat = datasetInput()$my_lat,stroke=FALSE, fillOpacity=0.4)
  })
  
  
  observe({
    
    colorData <- datasetInput()$Occupation.Name
    pal <- colorFactor('Spectral', colorData)
    
    colorData_income <- datasetInput()$income
    pal_income <- colorFactor('Spectral', colorData_income)
    
    leafletProxy('map', data=datasetInput()) %>%
      clearShapes() %>%
      clearMarkers() %>%
      addCircles(~my_lon, ~my_lat, radius= ~radius, layerId= ~zip_code,stroke=F, fillOpacity=0.7, fillColor = ~pal(Occupation.Name)) %>%
      addLegend('bottomleft', pal=pal, values=colorData, title='Occupation is:', layerId='colorLegend') 
  })
  
  output$map_cluster <- renderLeaflet({
    leaflet() %>%
      addTiles() %>%
      setView(lng = -93.85, lat = 37.45, zoom = 4) %>%
      addMarkers(lng = datasetInput()$my_lon, lat = datasetInput()$my_lat,clusterOptions=markerClusterOptions()
      )
  })
  
  
  output$kmeanPlot <- renderPlot({
    
    palette(c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3",
              "#FF7F00", "#FFFF33", "#A65628", "#F781BF", "#999999"))
    par(mar = c(5.1, 4.1, 4.1, 1))
    plot(clusterInput(),col = clusterAlgo()$clusters,pch = 20, cex = 3)
    points(clusterAlgo()$centers, pch = 4, cex = 4, lwd = 4)
    
    if ('education_code' %in% colnames(clusterInput())) {
      legend(4, 4, legend = c(paste(education_mapping$education_code[1],'=', education_mapping$Education[1]),
                              paste(education_mapping$education_code[2],'=', education_mapping$Education[2]),
                              paste(education_mapping$education_code[3],'=', education_mapping$Education[3]),
                              paste(education_mapping$education_code[4],'=', education_mapping$Education[4])), 
             bty = "n")}})
  
  output$statist <- renderPlot({
    par(mar = c(4, 4, .1, .1))
    ggplot(data=datasetInput_stat(), 
           aes(x=political,
               y=number,
               fill = gender)
    ) + geom_bar(stat='identity')+geom_text(aes(label=number),position="stack",vjust=1)
  })
  
  
  output$table <- renderDataTable(
    {v12_mil}
  )
  
  output$downloadData <- downloadHandler(
    filename = 'v12_dataset',
    content = function(file) {
      sep <- switch(input$filetype, "csv" = ",", "tsv" = "\t")
      write.table(v12_mil, file, sep = ',',
                  row.names = FALSE)
    }
  )})
