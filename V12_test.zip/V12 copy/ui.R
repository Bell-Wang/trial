

library(shiny)
library(leaflet)

navbarPage("V12", id='nav',
           tabPanel("Interactive Map",
                    
                    div(class='outer',
                        tags$head(
                          includeCSS("styles.css")
                        ),
                        leafletOutput("map", width="100%", height="100%"),
                        absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                                      draggable = TRUE, top = 60, left = "auto", right = 20, bottom = "auto",
                                      width = 330, height = "auto",
                                      h2("V12 EXPLORER"),
                                      sliderInput("n_sample", "Data Size:", min = 1000, max = 56000, value = 1000, step = 1000),
                                      selectInput("Occupation.Name", "Occupation:", choices=c("All", occupation_select)),
                                      selectInput("state", "State:", choices= c("All", state_select)),
                                      selectInput("income", "Household Income (K):", choices=c("All", income_select)),
                                      selectInput("Education", "Education:", choices= c("All", education_select)),
                                      selectInput("political", "Political:",  choices = c("All", political_select))
                        )
                    )
           ),
           
           tabPanel("Clustering",
                    
                    div(class='outer',
                        tags$head(
                          includeCSS("styles.css")
                        ),
                        leafletOutput("map_cluster", width="100%", height="100%"),
                        absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                                      draggable = TRUE, top = 60, left = "auto", right = 20, bottom = "auto",
                                      width = 330, height = "auto",
                                      h2("V12 Clustering"),
                                      numericInput('clusters', 'Cluster Number', 3,
                                                   min = 1, max = 8),
                                      selectInput('var1', 'I am interested in checking clusters based on', cluster_select),
                                      selectInput('var2', 'and', cluster_select),
                                      plotOutput('kmeanPlot')
                        )
                    )
           ),
       
           tabPanel("Statistics",
                    fluidPage(
                      titlePanel('Some statistics'),
                    sidebarLayout(
                      sidebarPanel(
                        br(),
                        h3("This is only a placeholder/demo, 
                           more features will be added here......"),
                        br(),
                        br(),
                        selectInput("var_1", "I want to see:", 'gender'),
                        selectInput("var_2", "in:", 
                                    'political')),
                    mainPanel(plotOutput("statist"))))),
           tabPanel("Summary",
                    dataTableOutput("table")
           )
           # ,
           # tabPanel("DataSet Downloads",
           #          fluidPage(
           #            titlePanel('File download'),
           #            sidebarLayout(
           #              sidebarPanel(
           #                radioButtons("filetype", "File type:",
           #                             choices = c("csv", "tsv")),
           #                downloadButton('downloadData', 'Download')
           #              ),
           #              mainPanel(
           #                tableOutput('table')
           #              )
           #            )
           #          )
#)
)

