

v12_mil <- read.csv("/data/v12_mil.csv")
occupation_select <- (unique(as.character(v12_mil$Occupation.Name)))
education_select <-(unique(as.character(v12_mil$Education)))
state_select <- (unique(as.character(v12_mil$state)))
political_select <- c("Democratic","Republican","Independent")
income_select <- c('Under $10K', 
'10-19,999', '20-29,999', '30-39,999', '40-49,999', '50-59,999', '60-69,999', 
'70-79,999', '80-89,999', '90-99,999', '100-149,999', '150-174,999','175-199,999',
'200-249,999','250K+')
  
  unique(as.character(v12_mil$income[which(!(is.na(v12_mil$income)))]))
cluster_select <- c('age','income','generation in household', 'number of children','current home value',
                    'education code','occupation')

v12_mil <- v12_mil[which(!is.na(v12_mil$my_lat)),]

v12_mil$radius <- 0
for (i in 1:nrow(v12_mil)){
  if (is.na(v12_mil$education_code[i])) {v12_mil$radius[i] <- 0}
  else if (v12_mil$education_code[i] == '1') {v12_mil$radius[i] <- 40000}
  else if (v12_mil$education_code[i] == '2') {v12_mil$radius[i] <- 60000}
  else if (v12_mil$education_code[i] == '3') {v12_mil$radius[i] <- 80000}
  else if (v12_mil$education_code[i] == '4') {v12_mil$radius[i] <- 100000}
}


occupation_mapping <- unique(v12_mil[,c('Occupation','Occupation.Name')])
education_mapping <- unique(v12_mil[,c('education_code','Education')])

gp_df <- as.data.frame(table(v12_mil[,c('gender','political')]))
gp_df <- gp_df[(gp_df$political!='' & gp_df$gender!=''),]
sp_df <- as.data.frame(table(v12_mil[,c('state','political')]))

ggplot(data=gp_df, 
       aes(x=political,
           y=Freq,
           fill = gender)
) + geom_bar(stat='identity')+geom_text(aes(label=Freq),position="stack",vjust=1)


